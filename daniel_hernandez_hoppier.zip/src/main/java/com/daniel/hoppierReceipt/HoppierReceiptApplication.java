package com.daniel.hoppierReceipt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoppierReceiptApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoppierReceiptApplication.class, args);
	}

}
